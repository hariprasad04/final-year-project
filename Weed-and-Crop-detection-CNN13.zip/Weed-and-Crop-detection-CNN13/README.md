Download weed-detection-in-soybean-crops.zip file in bellow url:
https://www.kaggle.com/fpeccia/weed-detection-in-soybean-crops

Dataset Acknowledgements:
The dataset used was created by Alessandro dos Santos Ferreira, Hemerson Pistori, Daniel Matte Freitas and Gercina Gonçalves da Silva. It is distributed under the CC BY NC 3.0 license.
Original URL: https://data.mendeley.com/datasets/3fmjm7ncc6/2
